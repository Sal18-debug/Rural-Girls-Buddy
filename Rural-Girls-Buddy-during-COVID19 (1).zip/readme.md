Title of Project Rural Girls Buddy

What is the purpose of your project?

The purpose of this project is to create an application tailored to help rural young female students receive further education they need to succeed. The current pandemic has disrupted many in terms of education, and in rural communities, young girls often get left behind their male peers in reaching further education. Rural Girls Budy helps also to support rural girls with their educational counseling as well as provide support tools for their mental strength

Why did you design this product and how it is useful to society?

Summary of Rural GIrls Buddy
This product is designed to help further educate rural girls. Besides lesson plans built upon local and national educational standards, this application includes features such as career tools, quizzes, grading systems, and a music relaxation feature based on a user’s expression to relieve tensions during these difficult times.

One of the also interesting features is the project galleries where student showcases their project and we invite the organization to view their project if they like then they can give some work opportunities to the student.

Main Features of Rural Girls Buddy
Quiz Portal Quizzes built upon local and national educational standards, this feature includes features such as career tools, quizzes.

Grade Student Portal
This product is designed to help further educate rural girls. Upon local district approval we are implementing the virtual girl learning plan and able to complete their grades and move forward to further study

Virtual Portal Gallery
We are also given chance to girls to demonstrate their projects with a virtual portal and get connected with the Organization An organization can connect with the student if they are interested in developing the further project and give student an internship opportunity

Career Counselling Portal
Benefits for Society
Rural Girls Buddy can replace the missing education that these groups of students are missing. If such education is slowly back on the right track, Rural Girls Buddy can serve as a supplemental tool to support such education. Rural Girls Buddy also provides mental support tools to increase mental strength to stand out in society. Rural Girls Buddy Helps rural girls to represent her voice in a community and helped them to stand out.

